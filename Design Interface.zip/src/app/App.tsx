import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, X, AlertTriangle, ArrowRight, Github, 
  ChevronRight, ZoomIn, ZoomOut, RefreshCw, Check, Info, 
  Mic, Sparkles, MapPin, Phone, Calendar, MessageCircle, FileText
} from 'lucide-react';

// --- DATA ---
const DRUG_DB = [
  { name: 'Aspirin', generic: 'Acetylsalicylic Acid', category: 'Pain' },
  { name: 'Ibuprofen', generic: 'Advil, Motrin', category: 'Pain' },
  { name: 'Metformin', generic: 'Glucophage', category: 'Diabetes' },
  { name: 'Lisinopril', generic: 'Prinivil, Zestril', category: 'Cardiovascular' },
  { name: 'Atorvastatin', generic: 'Lipitor', category: 'Cardiovascular' },
  { name: 'Amoxicillin', generic: 'Amoxil', category: 'Other' },
];

const INTERACTIONS = [
  {
    id: '1',
    drugs: ['Aspirin', 'Ibuprofen'],
    severity: 'SEVERE',
    description: 'Increased bleeding risk & diminished heart protection.',
    detail: 'Taking Aspirin and Ibuprofen together increases your risk of stomach bleeding by up to 3x. Ibuprofen may also reduce the heart-protective effects of low-dose Aspirin.',
    action: ['Talk to your doctor about alternatives', 'Never take both at the same time', 'Consider Acetaminophen instead of Ibuprofen'],
    evidence: 'FDA FAERS · 12,847 reports',
    color: '#FF453A',
    alternatives: [
      { name: 'Acetaminophen (Tylenol)', desc: 'Does not interfere with Aspirin benefits.' },
      { name: 'Topical NSAIDs', desc: 'Localized relief, lower systemic risk.' }
    ]
  },
  {
    id: '2',
    drugs: ['Metformin', 'Lisinopril'],
    severity: 'MODERATE',
    description: 'Risk of lactic acidosis.',
    detail: 'Using Metformin and Lisinopril together may increase the risk of a rare but serious condition called lactic acidosis, especially if you have kidney problems.',
    action: ['Monitor kidney function', 'Stay hydrated', 'Report muscle pain or weakness'],
    evidence: 'WHO VigiBase · 3,421 reports',
    color: '#FF9F0A',
    alternatives: [
      { name: 'Monitor closely', desc: 'Often managed safely under doctor supervision.' }
    ]
  }
];

// --- UTILS ---
const cx = (...args) => args.filter(Boolean).join(' ');
const glassClass = "bg-[rgba(30,30,35,0.4)] backdrop-blur-[40px] saturate-[150%] border border-white/[0.15] shadow-[inset_0_1px_0_rgba(255,255,255,0.1),0_20px_40px_rgba(0,0,0,0.4)]";

// --- COMPONENTS ---

const AppleBackground = ({ uiState }) => {
  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden bg-black pointer-events-none">
      {/* Base Aurora Waves */}
      <motion.div 
        className="absolute top-[-20%] left-[-10%] w-[70vw] h-[70vh] rounded-full blur-[120px] opacity-60 mix-blend-screen"
        style={{ background: '#0B132B' }}
        animate={{ x: [0, 50, -50, 0], y: [0, 30, -30, 0] }}
        transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div 
        className="absolute bottom-[-20%] right-[-10%] w-[60vw] h-[60vh] rounded-full blur-[140px] opacity-70 mix-blend-screen"
        style={{ background: '#1C0F24' }}
        animate={{ x: [0, -60, 40, 0], y: [0, -40, 20, 0] }}
        transition={{ duration: 25, repeat: Infinity, ease: 'easeInOut' }}
      />
      
      {/* Siri / Alert Edge Glow */}
      <motion.div 
        className="absolute inset-0 pointer-events-none box-border"
        animate={{
          boxShadow: uiState === 'listening' 
            ? 'inset 0 0 100px rgba(255,45,85,0.2), inset 0 0 150px rgba(50,215,75,0.15), inset 0 0 80px rgba(10,132,255,0.2)'
            : uiState === 'alert'
            ? 'inset 0 0 120px rgba(255,69,58,0.2)'
            : 'inset 0 0 0px rgba(0,0,0,0)'
        }}
        transition={{ duration: 1 }}
      />
      
      {/* Noise Texture */}
      <div 
        className="absolute inset-0 opacity-[0.03] mix-blend-overlay"
        style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.8%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}
      />
    </div>
  );
};

const PillNavbar = ({ onNavigate }) => {
  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 flex items-center justify-between px-6 py-3 rounded-[24px] w-[90%] max-w-[600px] transition-all">
      <div className={`absolute inset-0 rounded-[24px] ${glassClass} -z-10`} />
      
      <div 
        className="flex items-center gap-2 cursor-pointer group"
        onClick={() => onNavigate('hero')}
      >
        <span className="font-semibold text-[17px] tracking-tight">
          <span className="text-white">Med</span>
          <span className="text-[#34C759]">Safe AI</span>
        </span>
      </div>

      <div className="hidden sm:flex items-center gap-6">
        {['Home', 'How it Works'].map((item) => (
          <div 
            key={item} 
            className="text-[14px] font-medium text-[#A1A1A6] hover:text-white cursor-pointer transition-colors"
            onClick={() => {
              if (item === 'Home') onNavigate('hero');
            }}
          >
            {item}
          </div>
        ))}
      </div>

      <button className="text-[#A1A1A6] hover:text-white transition-colors">
        <Github className="w-5 h-5" />
      </button>
    </div>
  );
};

const SiriOrb = ({ active }) => (
  <div className="relative w-28 h-28 flex items-center justify-center">
    <motion.div 
      className="absolute inset-0 rounded-full blur-[20px] bg-gradient-to-tr from-[#FF2D55] via-[#AF52DE] to-[#32D74B] opacity-70"
      animate={{ 
        rotate: active ? 360 : 0,
        scale: active ? [1, 1.2, 1] : 1
      }}
      transition={{ 
        rotate: { duration: 4, repeat: Infinity, ease: 'linear' },
        scale: { duration: 2, repeat: Infinity, ease: 'easeInOut' }
      }}
    />
    <motion.div 
      className="absolute inset-3 rounded-full blur-[10px] bg-gradient-to-bl from-[#FF9F0A] to-[#0A84FF] opacity-90"
      animate={{ 
        rotate: active ? -360 : 0,
        scale: active ? [1, 1.1, 1] : 1
      }}
      transition={{ 
        rotate: { duration: 5, repeat: Infinity, ease: 'linear' },
        scale: { duration: 1.5, repeat: Infinity, ease: 'easeInOut' }
      }}
    />
    <div className="absolute inset-[15px] bg-white/5 backdrop-blur-md rounded-full border border-white/20 shadow-[inset_0_0_20px_rgba(255,255,255,0.3)] flex items-center justify-center">
      <Mic className={cx("w-8 h-8 transition-colors", active ? "text-white" : "text-white/70")} />
    </div>
  </div>
);

const HeroScreen = ({ onNavigate, setUiState }) => {
  const [listening, setListening] = useState(false);

  const toggleListen = () => {
    setListening(!listening);
    setUiState(!listening ? 'listening' : 'idle');
    if (!listening) {
      setTimeout(() => {
        setListening(false);
        setUiState('idle');
        onNavigate('input');
      }, 2500);
    }
  };

  return (
    <div className="min-h-screen pt-[160px] flex flex-col items-center justify-center relative">
      <div className="max-w-[700px] w-full px-6 flex flex-col items-center text-center z-10 relative">
        
        <div className="mb-10 cursor-pointer" onClick={toggleListen}>
          <SiriOrb active={listening} />
        </div>

        <h1 className="font-semibold text-[44px] md:text-[56px] text-white tracking-tight leading-[1.1] mb-4">
          Intelligent Drug Safety.<br/>Always Private.
        </h1>

        <p className="text-[17px] md:text-[19px] text-[#A1A1A6] font-medium max-w-[500px] leading-relaxed mb-12">
          {listening ? '"Listening..."' : '"Ask me to check your medications, or type them below."'}
        </p>

        <div className="w-full max-w-[480px] relative group">
          <div className={cx(`absolute inset-0 rounded-full transition-all duration-500`, listening ? "bg-white/10 blur-xl" : "bg-transparent")} />
          <button 
            onClick={toggleListen}
            className={cx(
              glassClass,
              "relative w-full h-[64px] rounded-full px-6 flex items-center gap-4 transition-all duration-300",
              listening ? "border-white/30 scale-105" : "hover:border-white/25 hover:bg-[rgba(40,40,45,0.5)]"
            )}
          >
            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center shrink-0">
              <Mic className={cx("w-5 h-5", listening ? "text-[#32D74B]" : "text-white")} />
            </div>
            <span className="text-[17px] text-[#A1A1A6] font-medium text-left flex-1">
              {listening ? 'I take Metformin and Aspirin...' : 'Tap to speak...'}
            </span>
          </button>
        </div>

        <button 
          onClick={() => onNavigate('input')}
          className="mt-6 text-[#0A84FF] text-[15px] font-medium hover:text-[#5E5CE6] transition-colors"
        >
          Type manually instead
        </button>

        <div className="mt-20 flex items-center gap-4 text-[#A1A1A6] text-[13px] font-medium uppercase tracking-widest">
          <div className="h-[1px] w-8 bg-white/20" />
          Built with WHO & FDA Open Data
          <div className="h-[1px] w-8 bg-white/20" />
        </div>
      </div>
    </div>
  );
};

const InputScreen = ({ onAnalyze }) => {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(['Aspirin', 'Ibuprofen']);
  const [isFocused, setIsFocused] = useState(false);
  
  const filteredDrugs = DRUG_DB.filter(d => 
    d.name.toLowerCase().includes(query.toLowerCase()) || 
    d.generic.toLowerCase().includes(query.toLowerCase())
  ).filter(d => !selected.includes(d.name));

  const addDrug = (name) => {
    if (!selected.includes(name)) {
      setSelected([...selected, name]);
      setQuery('');
    }
  };

  const removeDrug = (name) => {
    setSelected(selected.filter(d => d !== name));
  };

  return (
    <div className="min-h-screen pt-[140px] pb-20 px-6 flex flex-col items-center">
      <div className="max-w-[600px] w-full z-10 relative">
        
        {/* SEARCH INPUT */}
        <div className="relative mb-8">
          <div className={cx(
            glassClass,
            "w-full h-[60px] rounded-[20px] px-5 flex items-center transition-all",
            isFocused ? "border-[#0A84FF]/50 shadow-[0_0_0_4px_rgba(10,132,255,0.15)]" : ""
          )}>
            <Search className="w-[20px] h-[20px] text-[#A1A1A6] mr-3" />
            <input 
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setTimeout(() => setIsFocused(false), 200)}
              placeholder="Aspirin, Ibuprofen, Lisinopril..."
              className="flex-1 bg-transparent border-none outline-none text-white text-[17px] font-medium placeholder:text-[#A1A1A6]/60"
            />
            <div className="px-2 py-1 bg-white/10 rounded-md text-[13px] text-[#A1A1A6] font-medium hidden sm:block">
              Return
            </div>
          </div>

          <AnimatePresence>
            {isFocused && query && filteredDrugs.length > 0 && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.98 }}
                className={cx(glassClass, "absolute top-[72px] left-0 w-full overflow-hidden z-20 !rounded-[20px]")}
              >
                {filteredDrugs.slice(0, 5).map(drug => (
                  <div 
                    key={drug.name}
                    className="px-5 py-[16px] flex items-center gap-3 hover:bg-white/10 cursor-pointer border-b border-white/[0.05] last:border-0 transition-colors"
                    onClick={() => addDrug(drug.name)}
                  >
                    <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-[15px]">💊</div>
                    <div className="flex flex-col">
                      <span className="text-white text-[16px] font-medium">{drug.name}</span>
                      <span className="text-[#A1A1A6] text-[13px]">{drug.generic}</span>
                    </div>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* DRUG CHIPS */}
        <div className="mb-6">
          <h3 className="text-[15px] font-medium text-[#A1A1A6] mb-4 pl-1">Recognized Medications:</h3>
          <div className="flex flex-wrap gap-3">
            <AnimatePresence>
              {selected.map(drug => (
                <motion.div 
                  key={drug}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className={cx(glassClass, "!rounded-full pl-4 pr-2 py-2 flex items-center gap-2 hover:bg-white/10 transition-colors")}
                >
                  <span className="text-white font-medium text-[15px]">{drug}</span>
                  <button 
                    onClick={() => removeDrug(drug)}
                    className="w-[24px] h-[24px] rounded-full bg-white/10 flex items-center justify-center text-[#A1A1A6] hover:bg-[#FF453A] hover:text-white transition-colors"
                  >
                    <X className="w-[14px] h-[14px]" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* AI INSIGHT */}
        <AnimatePresence>
          {selected.length >= 2 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={cx(glassClass, "p-6 mb-8 relative overflow-hidden group")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[#AF52DE]/10 to-[#0A84FF]/10 opacity-50" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 text-[#AF52DE] font-semibold text-[15px] mb-2">
                  <Sparkles className="w-5 h-5" />
                  AI Insight
                </div>
                <p className="text-[#E5E5EA] text-[16px] leading-relaxed font-medium">
                  "I noticed you added two NSAIDs (painkillers). Let's analyze this combination for safety."
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* GENERATE BUTTON */}
        <button 
          disabled={selected.length === 0}
          onClick={() => onAnalyze(selected)}
          className={cx(
            "w-full h-[60px] rounded-[20px] flex items-center justify-center gap-2 font-semibold text-[17px] transition-all active:scale-[0.98]",
            selected.length > 0 
              ? "bg-white text-black shadow-[0_8px_30px_rgba(255,255,255,0.2)] hover:bg-[#F2F2F7]" 
              : "bg-white/10 text-white/40 cursor-not-allowed"
          )}
        >
          <Sparkles className="w-5 h-5" />
          Generate Safety Report ({selected.length} drugs)
        </button>

      </div>
    </div>
  );
};

// --- GRAPH UTILS ---
const GRAPH_RADIUS = 160;
const getNodePosition = (index, total, centerX, centerY) => {
  const angle = (index / total) * 2 * Math.PI - Math.PI / 2;
  return {
    x: centerX + GRAPH_RADIUS * Math.cos(angle),
    y: centerY + GRAPH_RADIUS * Math.sin(angle)
  };
};
const getEdgePath = (p1, p2) => `M ${p1.x} ${p1.y} L ${p2.x} ${p2.y}`;

const ResultsScreen = ({ selectedDrugs, setUiState }) => {
  const [selectedInteraction, setSelectedInteraction] = useState(null);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const containerRef = useRef(null);
  const [dimensions, setDimensions] = useState({ w: 800, h: 600 });

  const activeInteractions = INTERACTIONS.filter(i => 
    i.drugs.every(d => selectedDrugs.includes(d))
  );

  const severeCount = activeInteractions.filter(i => i.severity === 'SEVERE').length;
  const isSevere = severeCount > 0;

  useEffect(() => {
    if (isSevere) {
      setUiState('alert');
    } else {
      setUiState('idle');
    }
    
    if (containerRef.current) {
      setDimensions({
        w: containerRef.current.offsetWidth,
        h: containerRef.current.offsetHeight
      });
    }
  }, [isSevere, setUiState]);

  const center = { x: dimensions.w / 2, y: dimensions.h / 2 };
  const nodes = selectedDrugs.map((d, i) => {
    const pos = getNodePosition(i, selectedDrugs.length, center.x, center.y);
    let color = 'rgba(255,255,255,0.8)';
    return { name: d, ...pos, color };
  });

  const edges = [];
  activeInteractions.forEach(interaction => {
    const n1 = nodes.find(n => n.name === interaction.drugs[0]);
    const n2 = nodes.find(n => n.name === interaction.drugs[1]);
    if (n1 && n2) {
      edges.push({
        n1, n2, 
        color: interaction.color, 
        width: interaction.severity === 'SEVERE' ? 4 : 3,
        interaction
      });
    }
  });

  return (
    <div className="min-h-screen pt-[88px] pb-6 px-6 flex flex-col md:flex-row gap-6 max-w-[1400px] mx-auto z-10 relative">
      
      {/* LEFT: GRAPH AREA */}
      <div 
        ref={containerRef}
        className={cx(glassClass, "flex-1 relative h-[50vh] md:h-[calc(100vh-120px)] overflow-hidden")}
      >
        <div className="absolute top-6 left-6 text-[15px] font-semibold text-white/70">
          Knowledge Graph
        </div>
        
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          {edges.map((e, i) => (
            <g key={i}>
              <motion.path 
                d={getEdgePath(e.n1, e.n2)}
                stroke={e.color}
                strokeWidth={e.width}
                fill="none"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ type: 'spring', duration: 2, delay: i * 0.2 }}
                style={{ filter: `drop-shadow(0 0 12px ${e.color})` }}
              />
              {/* Particle flow for severe */}
              {e.interaction.severity === 'SEVERE' && (
                <circle r="3" fill="#FFF" style={{ filter: 'drop-shadow(0 0 5px #FFF)' }}>
                  <animateMotion dur="1.5s" repeatCount="indefinite" path={getEdgePath(e.n1, e.n2)} />
                </circle>
              )}
            </g>
          ))}
        </svg>

        {nodes.map((node, i) => (
          <motion.div
            key={node.name}
            drag
            dragConstraints={containerRef}
            dragElastic={0.2}
            className="absolute w-[64px] h-[64px] -ml-[32px] -mt-[32px] rounded-full flex items-center justify-center cursor-grab active:cursor-grabbing hover:scale-105 transition-transform z-10"
            style={{
              left: node.x,
              top: node.y,
              background: 'radial-gradient(130% 130% at 30% 20%, rgba(255,255,255,0.2) 0%, rgba(0,0,0,0.8) 100%)',
              boxShadow: 'inset 0 2px 4px rgba(255,255,255,0.4), inset 0 -2px 10px rgba(0,0,0,0.5), 0 10px 20px rgba(0,0,0,0.5)',
              backdropFilter: 'blur(10px)'
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', bounce: 0.5, delay: i * 0.1 }}
          >
            <span className="font-semibold text-[12px] text-white text-center leading-tight px-1">
              {node.name}
            </span>
          </motion.div>
        ))}

        <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
          <button 
            onClick={() => isSevere && setShowLocationModal(true)}
            className={cx(
              "px-5 py-3 rounded-full flex items-center gap-2 font-medium text-[14px] transition-all",
              isSevere 
                ? "bg-[#FF453A] text-white hover:bg-[#FF453A]/90 shadow-[0_4px_14px_rgba(255,69,58,0.4)]" 
                : "bg-white/10 text-white hover:bg-white/20"
            )}
          >
            <MapPin className="w-4 h-4" /> Find Nearest Doctor
          </button>
        </div>
      </div>

      {/* RIGHT: RISK PANEL */}
      <div className="w-full md:w-[400px] flex flex-col gap-6 h-[50vh] md:h-[calc(100vh-120px)]">
        
        {/* Overall Risk Widget */}
        <div className={cx(glassClass, "p-6 shrink-0")}>
          <div className="text-[15px] font-semibold text-white/70 mb-4">Overall Risk</div>
          <div className="flex items-center gap-4">
            <div className={cx(
              "w-14 h-14 rounded-full flex items-center justify-center shadow-[inset_0_0_10px_rgba(255,255,255,0.2)]",
              isSevere ? "bg-[#FF453A] shadow-[0_0_20px_rgba(255,69,58,0.4)]" : "bg-[#34C759]"
            )}>
              {isSevere ? <AlertTriangle className="w-7 h-7 text-white" /> : <Check className="w-7 h-7 text-white" />}
            </div>
            <div>
              <div className="text-[24px] font-bold text-white tracking-tight">
                {isSevere ? 'SEVERE' : 'SAFE'}
              </div>
              <div className="text-[14px] text-[#A1A1A6] font-medium">
                {activeInteractions.length} Interactions Found
              </div>
            </div>
          </div>
        </div>

        {/* AI Summary Widget */}
        <div className={cx(glassClass, "p-6 shrink-0 relative overflow-hidden")}>
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#AF52DE]/20 to-transparent rounded-full blur-xl" />
          <div className="flex items-center gap-2 text-[#AF52DE] font-semibold text-[15px] mb-3 relative z-10">
            <Sparkles className="w-5 h-5" /> AI Summary
          </div>
          <p className="text-white font-medium text-[16px] leading-relaxed relative z-10">
            {isSevere ? '"High bleeding risk detected. Medical consultation recommended before continuing this regimen."' : '"No critical interactions found. You are good to go!"'}
          </p>
        </div>

        {/* Interactions List */}
        <div className={cx(glassClass, "flex-1 p-6 overflow-y-auto flex flex-col")}>
          <div className="text-[15px] font-semibold text-white/70 mb-4">Interactions</div>
          
          <div className="space-y-3">
            {activeInteractions.length === 0 ? (
              <div className="text-center py-6 text-[#A1A1A6] font-medium">No known interactions.</div>
            ) : (
              activeInteractions.map(interaction => (
                <div 
                  key={interaction.id}
                  onClick={() => setSelectedInteraction(interaction)}
                  className="bg-white/5 border border-white/10 rounded-[16px] p-4 cursor-pointer hover:bg-white/10 transition-colors active:scale-[0.98]"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: interaction.color, boxShadow: `0 0 8px ${interaction.color}` }} />
                    <span className="text-[13px] font-bold tracking-wide" style={{ color: interaction.color }}>
                      {interaction.severity}
                    </span>
                  </div>
                  <div className="text-white font-semibold text-[16px] mb-1">
                    {interaction.drugs.join(' + ')}
                  </div>
                  <div className="text-[#A1A1A6] text-[14px] line-clamp-1">
                    {interaction.description}
                  </div>
                </div>
              ))
            )}
          </div>
          
          <button className="mt-auto pt-6 w-full flex items-center justify-center gap-2 text-[#0A84FF] font-medium text-[15px] hover:text-[#5E5CE6] transition-colors">
            <FileText className="w-5 h-5" /> Download PDF Report
          </button>
        </div>
      </div>

      {/* DETAIL PANEL (AI ALTERNATIVES) */}
      <AnimatePresence>
        {selectedInteraction && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-md z-[60]"
              onClick={() => setSelectedInteraction(null)}
            />
            <motion.div 
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className={cx(
                "fixed bottom-0 left-0 right-0 md:left-1/2 md:-translate-x-1/2 md:bottom-10 md:w-full md:max-w-[600px] z-[70]",
                "bg-[rgba(30,30,35,0.85)] backdrop-blur-[40px] saturate-[150%] border border-white/[0.15] shadow-[0_-20px_60px_rgba(0,0,0,0.5)]",
                "rounded-t-[32px] md:rounded-[32px] flex flex-col max-h-[85vh]"
              )}
            >
              <div className="p-8 overflow-y-auto">
                <div className="flex justify-center md:hidden mb-6">
                  <div className="w-12 h-1.5 bg-white/20 rounded-full" />
                </div>
                
                <button 
                  onClick={() => setSelectedInteraction(null)}
                  className="absolute top-6 right-6 w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-[#A1A1A6] hover:bg-white/20 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2 mb-4">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedInteraction.color, boxShadow: `0 0 10px ${selectedInteraction.color}` }} />
                  <span className="text-[13px] font-bold tracking-wider uppercase" style={{ color: selectedInteraction.color }}>
                    {selectedInteraction.severity} INTERACTION
                  </span>
                </div>

                <h2 className="font-semibold text-[32px] text-white tracking-tight mb-8">
                  {selectedInteraction.drugs.join(' + ')}
                </h2>

                {/* AI Recommendation Box */}
                <div className="bg-gradient-to-br from-[#AF52DE]/10 to-[#0A84FF]/10 border border-[#AF52DE]/20 rounded-[20px] p-6 mb-8">
                  <div className="flex items-center gap-2 text-[#AF52DE] font-semibold text-[15px] mb-3">
                    <Sparkles className="w-5 h-5" /> AI Recommendation
                  </div>
                  <p className="text-white text-[16px] leading-relaxed font-medium mb-0">
                    "Since you are taking Aspirin for heart health, taking Ibuprofen for pain can block Aspirin's benefits and cause bleeding."
                  </p>
                </div>

                {/* Alternatives Box */}
                <div className="mb-8">
                  <h3 className="font-semibold text-[18px] text-white flex items-center gap-2 mb-4">
                    <Info className="w-5 h-5 text-[#34C759]" /> Safer Alternatives to ask about:
                  </h3>
                  <div className="space-y-3">
                    {selectedInteraction.alternatives.map((alt, i) => (
                      <div key={i} className="bg-white/5 border border-[#34C759]/30 rounded-[16px] p-4 shadow-[inset_0_0_20px_rgba(52,199,89,0.05)]">
                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-[#34C759]/20 flex items-center justify-center shrink-0 mt-0.5">
                            <Check className="w-4 h-4 text-[#34C759]" />
                          </div>
                          <div>
                            <div className="text-white font-semibold text-[16px]">{alt.name}</div>
                            <div className="text-[#A1A1A6] text-[14px] mt-1">{alt.desc}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="text-[#A1A1A6] text-[13px] text-center font-medium bg-white/5 p-4 rounded-[16px]">
                  Disclaimer: I am an AI, not a doctor. Please discuss these options with a physician.
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* LOCATION EMERGENCY MODAL */}
      <AnimatePresence>
        {showLocationModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
              onClick={() => setShowLocationModal(false)}
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className={cx(glassClass, "w-full max-w-[480px] p-8 relative z-10 flex flex-col")}
            >
              <button 
                onClick={() => setShowLocationModal(false)}
                className="absolute top-6 right-6 text-[#A1A1A6] hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="w-12 h-12 rounded-full bg-[#FF453A]/20 flex items-center justify-center mb-6 shadow-[0_0_20px_rgba(255,69,58,0.3)]">
                <MapPin className="w-6 h-6 text-[#FF453A]" />
              </div>

              <h2 className="font-semibold text-[24px] text-white tracking-tight mb-2">
                Emergency Routing
              </h2>
              <p className="text-[#A1A1A6] text-[15px] mb-8 font-medium">
                We've located medical care near you.
              </p>

              <div className="space-y-4">
                <div className="bg-white/10 rounded-[16px] p-5 border border-white/5">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-white font-semibold text-[17px] mb-1">🏥 City Hospital ER</div>
                      <div className="text-[#A1A1A6] text-[14px]">2.4 miles away • <span className="text-[#34C759]">Open Now</span></div>
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4">
                    <button className="flex-1 py-2.5 bg-white/10 rounded-full text-white font-medium text-[14px] flex items-center justify-center gap-2 hover:bg-white/20 transition-colors">
                      <Phone className="w-4 h-4" /> Call
                    </button>
                    <button className="flex-1 py-2.5 bg-[#0A84FF] rounded-full text-white font-medium text-[14px] flex items-center justify-center gap-2 hover:bg-[#0A84FF]/80 transition-colors shadow-[0_4px_12px_rgba(10,132,255,0.3)]">
                      <MapPin className="w-4 h-4" /> Directions
                    </button>
                  </div>
                </div>

                <div className="bg-white/10 rounded-[16px] p-5 border border-white/5">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-white font-semibold text-[17px] mb-1">🩺 Dr. Sharma (Cardio)</div>
                      <div className="text-[#A1A1A6] text-[14px]">3.1 miles away • Closes in 2h</div>
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4">
                    <button className="flex-1 py-2.5 bg-white/10 rounded-full text-white font-medium text-[14px] flex items-center justify-center gap-2 hover:bg-white/20 transition-colors">
                      <Phone className="w-4 h-4" /> Call
                    </button>
                    <button className="flex-1 py-2.5 bg-white/10 rounded-full text-white font-medium text-[14px] flex items-center justify-center gap-2 hover:bg-white/20 transition-colors">
                      <Calendar className="w-4 h-4" /> Book
                    </button>
                  </div>
                </div>

                <div className="bg-white/10 rounded-[16px] p-5 border border-white/5">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-white font-semibold text-[17px] mb-1">💻 24/7 Telehealth</div>
                      <div className="text-[#A1A1A6] text-[14px]">Available immediately</div>
                    </div>
                  </div>
                  <button className="w-full mt-4 py-2.5 bg-white/10 rounded-full text-white font-medium text-[14px] flex items-center justify-center gap-2 hover:bg-white/20 transition-colors">
                    <MessageCircle className="w-4 h-4" /> Start Chat
                  </button>
                </div>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};

// --- MAIN APP ---
export default function App() {
  const [screen, setScreen] = useState('hero'); // hero, input, results
  const [selectedDrugs, setSelectedDrugs] = useState([]);
  const [uiState, setUiState] = useState('idle'); // idle, listening, alert

  const handleAnalyze = (drugs) => {
    setSelectedDrugs(drugs);
    setScreen('results');
  };

  const handleNavigate = (target) => {
    setScreen(target);
    if (target !== 'results') setUiState('idle');
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen bg-black text-[#A1A1A6] font-sans selection:bg-[#0A84FF]/30 selection:text-white">
      <AppleBackground uiState={uiState} />
      <PillNavbar onNavigate={handleNavigate} />
      
      <AnimatePresence mode="wait">
        {screen === 'hero' && (
          <motion.div key="hero" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, filter: 'blur(10px)' }} transition={{ duration: 0.4 }}>
            <HeroScreen onNavigate={handleNavigate} setUiState={setUiState} />
          </motion.div>
        )}
        
        {screen === 'input' && (
          <motion.div key="input" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ duration: 0.4, type: 'spring' }}>
            <InputScreen onAnalyze={handleAnalyze} />
          </motion.div>
        )}

        {screen === 'results' && (
          <motion.div key="results" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.5, type: 'spring' }}>
            <ResultsScreen selectedDrugs={selectedDrugs} setUiState={setUiState} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
